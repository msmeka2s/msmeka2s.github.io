<template>
  <div id="app">
    <www-navigator></www-navigator>
  </div>
</template>

<script>
import wwwNavigator from './components/wwwNavigator.vue';

export default {
  name: 'App',
  components: {
    wwwNavigator
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  background: #fff;
}
</style>